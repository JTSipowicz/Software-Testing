Singly Linked List Program
Author: James T Sipowicz III
Instructor: Dr. Guowei Yang
Date: 2/10/20
CS-3393 Software Testing, Spring 2020 Texas State

Effectiveness of various test cases:
�   Since I didn't know how to correctly implement JUnit Test cases,
	I used print statements to test how effective my methods were.
	My program functions very well, but it is limited in that:
	- Only integer objects can be added onto the list.

ADD:
� Pros:
	Passes following tests:
	- Test if a value is successfully added to the list
	- Value of element doesn't effect placement
	
� Cons: 
	Method still incorrectly adds duplicates.
	
REMOVE:
� Pros:
	Passes following tests:
	- Test if a value can be successfully removed from the list
	- Test if removing a value that doesn't exist in the list causes 
	  issues
	  
� Cons:
	Method only correctly removes objects in sequential deletion.
	
SIZE:
� Pros:
	Works Perfectly

EQUALS:
� Pros:
	Passes following tests:
	- Test if searching for a value that is an instance of an int,
	  and is in the list returns true
	- Test if searching for a value that is an instance of an int,
	  but isn't in the list returns false
	- Test if searching for a a value that isn't an instance of an 
	  int returns false
