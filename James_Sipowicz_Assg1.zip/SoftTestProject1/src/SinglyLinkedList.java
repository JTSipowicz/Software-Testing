/*	Singly Linked List Program
 *  Author: James T Sipowicz III
 * 	Instructor: Dr. Guowei Yang
 *  Date: 2/10/20
 *  CS-3393 Software Testing, Spring 2020 Texas State
 */
public class SinglyLinkedList {
	private static class Node {
		private int data;
		private Node next;
		public Node(int data, Node next) {
			this.data = data;
			this.next = next;
		}
	}
	private Node head = null;
	int size = 0;
	
	// 4 Required Member Functions
	public boolean add(int e) {
		boolean status = false;
		if (head == null) {
			insertHead(e);
		} else {
			Node temp = this.head;
			while (temp.next != null) {
				temp = temp.next;
			}
			insertAfter(e, temp);
		}
		return status;
	}
	public boolean remove(int e) {
		boolean status = false;
		Node temp = this.head;
		if (temp.data == e) {
			removeHead();
		} else {
			return status;
		}
		return status;
	}
	public boolean equals(Object obj) {
		boolean status = false;
		if (obj instanceof Integer) {
			int data = (int) obj;
			Node temp = this.head;
			while (temp != null) {
				if (temp.data == data) {
					status = true;
					break;
				}
				temp = temp.next;
			}
			return status;
		}else{
			return status;
		}
	}
	public int size() {
		Node temp = head;
		while (temp != null) {
			size++;
			temp = temp.next;
		}
		return size;
	}
	// Helper Functions
	private void insertHead(int value) {
		this.head = new Node(value, this.head);
		size++;
	}
	private void insertAfter(int value, Node node) {
		node.next = new Node(value, node.next);
		size++;
	}
	private boolean removeHead() {
		boolean status = false;
		// Reference copied here
		Node temp = this.head;
		if (head != null) {
			this.head = this.head.next;
		}
		if (temp != null) {
			size--;
			status = true;
		}
		return status;
	}
	public String toString() {
		StringBuilder output = new StringBuilder();
		Node temp = head;
		System.out.print("�");
		while (temp != null) {
			output.append(temp.data);
			if (temp.next != null) {
				output.append(" � ");
			}
			temp = temp.next;
		}
		return output.append("�").toString();
	}
	public static void main(String[] args) {
		SinglyLinkedList linkedList = new SinglyLinkedList();
		// ADD: Test if a value is successfully added to the list
		linkedList.add(3);
		System.out.println(linkedList);
		System.out.println(linkedList.size);
		// ADD: Test if adding a duplicate value returns false
		linkedList.add(3);
		linkedList.add(6);
		linkedList.add(9);
		linkedList.add(12);
		System.out.println(linkedList);
		System.out.println(linkedList.size);
		// REMOVE: Test if a value can be successfully removed from the list
		linkedList.remove(3);
		linkedList.remove(3);
		// REMOVE: Test if removing a value that doesn't exist in the list causes issues
		linkedList.remove(7);
		linkedList.remove(6);
		System.out.println(linkedList);
		System.out.println(linkedList.size);
		// Test if searching for a value that is an instance of an int,
		// and is in the list returns true
		System.out.println(linkedList.equals(9));
		// Test if searching for a value that is an instance of an int,
		// but isn't in the list returns false
		System.out.println(linkedList.equals(10));
		// Test if searching for a a value that isn't an instance of an int returns false
		System.out.println(linkedList.equals("3"));
	}
}